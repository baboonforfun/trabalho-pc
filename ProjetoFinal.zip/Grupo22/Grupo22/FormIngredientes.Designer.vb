﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIngredientes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Nome = New System.Windows.Forms.TextBox()
        Me.Precoo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Quantidadee = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.AdicionarRemover = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Ing = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.GridIng = New System.Windows.Forms.DataGridView()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Nome
        '
        Me.Nome.Location = New System.Drawing.Point(138, 69)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(100, 20)
        Me.Nome.TabIndex = 0
        '
        'Precoo
        '
        Me.Precoo.Location = New System.Drawing.Point(138, 111)
        Me.Precoo.Name = "Precoo"
        Me.Precoo.Size = New System.Drawing.Size(100, 20)
        Me.Precoo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(93, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nome"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(54, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Preço/unidade"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(70, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Quantidade"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(280, 58)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 41)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Criar Ingrediente"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(569, 58)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 41)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Adicionar Quantidade"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Quantidadee
        '
        Me.Quantidadee.Location = New System.Drawing.Point(138, 149)
        Me.Quantidadee.Name = "Quantidadee"
        Me.Quantidadee.Size = New System.Drawing.Size(100, 20)
        Me.Quantidadee.TabIndex = 8
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(569, 128)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(90, 41)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Remover Quantidade"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(395, 110)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Quantidade"
        '
        'AdicionarRemover
        '
        Me.AdicionarRemover.Location = New System.Drawing.Point(463, 107)
        Me.AdicionarRemover.Name = "AdicionarRemover"
        Me.AdicionarRemover.Size = New System.Drawing.Size(100, 20)
        Me.AdicionarRemover.TabIndex = 11
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(280, 105)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(90, 36)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Registar ingrediente"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(305, 12)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 23)
        Me.Button6.TabIndex = 14
        Me.Button6.Text = ">>"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(254, 12)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 23)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = ">"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(87, 12)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 23)
        Me.Button7.TabIndex = 16
        Me.Button7.Text = "<<"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(138, 12)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 23)
        Me.Button8.TabIndex = 17
        Me.Button8.Text = "<"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Ing
        '
        Me.Ing.AutoSize = True
        Me.Ing.Location = New System.Drawing.Point(199, 17)
        Me.Ing.Name = "Ing"
        Me.Ing.Size = New System.Drawing.Size(37, 13)
        Me.Ing.TabIndex = 18
        Me.Ing.Text = "0 de 0"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(280, 147)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(90, 36)
        Me.Button9.TabIndex = 22
        Me.Button9.Text = "Remover ingrediente"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'GridIng
        '
        Me.GridIng.AllowUserToAddRows = False
        Me.GridIng.AllowUserToDeleteRows = False
        Me.GridIng.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridIng.Location = New System.Drawing.Point(183, 220)
        Me.GridIng.Name = "GridIng"
        Me.GridIng.ReadOnly = True
        Me.GridIng.Size = New System.Drawing.Size(357, 219)
        Me.GridIng.TabIndex = 27
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(479, 14)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(180, 20)
        Me.Numero.TabIndex = 74
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(665, 12)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 23)
        Me.Button10.TabIndex = 75
        Me.Button10.Text = ">"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(428, 12)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(45, 23)
        Me.Button11.TabIndex = 76
        Me.Button11.Text = "<"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'FormIngredientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 451)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.GridIng)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Ing)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.AdicionarRemover)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Quantidadee)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Precoo)
        Me.Controls.Add(Me.Nome)
        Me.Name = "FormIngredientes"
        Me.Text = "FormIngredientes"
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Nome As TextBox
    Friend WithEvents Precoo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Quantidadee As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents AdicionarRemover As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Ing As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents GridIng As DataGridView
    Friend WithEvents Numero As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
End Class
