﻿Module VarGlobal
    Public Cadeia As Restaurantes
    Public visivel2 As Integer
    Public restaurante As New Restaurante
    Public visivel3 As Integer
    Public Sub initvars()
        Cadeia = New Restaurantes
        Cadeia.ler()
        MsgBox(Cadeia.Count)
        If Cadeia.Count > 0 Then
            MsgBox("ola")
            visivel2 = Cadeia.Count - 1
        Else
            Cadeia.Add(restaurante)
            visivel2 = 0
            visivel3 = 0

        End If

    End Sub
End Module
