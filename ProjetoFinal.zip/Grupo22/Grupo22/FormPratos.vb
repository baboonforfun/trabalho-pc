﻿Public Class FormPratos
    Public visivell As Integer = 0
    Public visivel As Integer = 0
    Private Sub FormPratos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicial()
        mostra()
        mostra2()



    End Sub

    Public Sub mostra()
        If Cadeia.Count > 0 Then
            If visivel2 < 0 Then
                visivel2 = 0
            ElseIf visivel2 > Cadeia.Count - 1 Then
                visivel2 = Cadeia.Count - 1
            End If
            Numero.Text = "Restaurante " & Cadeia(visivel2).Nome
        End If

        If visivel2 = 0 Then
            Button6.Enabled = False
            Button5.Enabled = True
        ElseIf visivel2 = Cadeia.Count - 1 Then
            Button6.Enabled = True
            Button5.Enabled = False
        End If
        If Cadeia.Count = 1 Then
            Button6.Enabled = False
            Button5.Enabled = False
        End If
        If Cadeia(visivel2).Pratos.Count > 0 Then
            If visivel < 0 Then
                visivel = 0
            ElseIf visivel > Cadeia(visivel2).Pratos.Count - 1 Then
                visivel = Cadeia(visivel2).Pratos.Count - 1
            End If

            If visivel = 0 Then
                Botao1.Enabled = False
                Botao2.Enabled = False
                Botao3.Enabled = True
                Botao4.Enabled = True
            ElseIf visivel = Cadeia(visivel2).Pratos.Count - 1 Then
                Botao1.Enabled = True
                Botao2.Enabled = True
                Botao3.Enabled = False
                Botao4.Enabled = False
            Else
                Botao1.Enabled = True
                Botao2.Enabled = True
                Botao3.Enabled = True
                Botao4.Enabled = True
            End If

            If visivel = 0 And Cadeia(visivel2).Pratos.Count = 1 Then
                Botao1.Enabled = False
                Botao2.Enabled = False
                Botao3.Enabled = False
                Botao4.Enabled = False
                RegistarPrato.Visible = True
                Entrada.Enabled = True
                PratoPrincipal.Enabled = True
                Sobremesa.Enabled = True
                NomePrato.Enabled = True
                Preco.Enabled = True
            End If

            NomePrato.Text = Cadeia(visivel2).Pratos(visivel).Nome
            Preco.Text = Cadeia(visivel2).Pratos(visivel).Preco
            TipoPrato.Text = Cadeia(visivel2).Pratos(visivel).Tipo

            Pratos.Text = visivel + 1 & " de " & Cadeia(visivel2).Pratos.Count



            Lista.Items.Clear()
            For k = 0 To Cadeia(visivel2).Ingredientes.Count - 1
                Lista.Items.Add(Cadeia(visivel2).Ingredientes(k).Nome & vbTab & Cadeia(visivel2).Ingredientes(k).Quantidade)
            Next

            ListaPratos.Items.Clear()
            For k = 0 To Cadeia(visivel2).Pratos.Count - 1
                ListaPratos.Items.Add(Cadeia(visivel2).Pratos(k).Nome)
            Next
        Else
            inicial()
        End If
    End Sub

    Public Sub inicial()
        RegistarPrato.Visible = False
        Botao1.Enabled = False
        Botao2.Enabled = False
        Botao3.Enabled = False
        Botao4.Enabled = False
        TipoPrato.Enabled = False
        Numero.Enabled = False
        RegPratoDia.Visible = False
    End Sub

    Private Sub CriarPrato_Click(sender As Object, e As EventArgs) Handles CriarPrato.Click
        Dim pratos As Prato
        pratos = New Prato
        Cadeia(visivel2).Pratos.Add(pratos)
        visivel = Cadeia(visivel2).Pratos.Count - 1
        mostra()
    End Sub

    Private Sub Botao3_Click(sender As Object, e As EventArgs) Handles Botao3.Click
        visivel = visivel + 1
        mostra()
    End Sub

    Private Sub Botao4_Click(sender As Object, e As EventArgs) Handles Botao4.Click
        visivel = Cadeia(visivel2).Pratos.Count - 1
        mostra()
    End Sub

    Private Sub Botao2_Click(sender As Object, e As EventArgs) Handles Botao2.Click
        visivel = visivel - 1
        mostra()
    End Sub

    Private Sub Botao1_Click(sender As Object, e As EventArgs) Handles Botao1.Click
        visivel = 0
        mostra()
    End Sub

    Private Sub Entrada_Click(sender As Object, e As EventArgs) Handles Entrada.Click
        TipoPrato.Text = "Entrada"

    End Sub

    Private Sub PratoPrincipal_Click(sender As Object, e As EventArgs) Handles PratoPrincipal.Click
        TipoPrato.Text = "Prato Principal"
    End Sub

    Private Sub Sobremesa_Click(sender As Object, e As EventArgs) Handles Sobremesa.Click
        TipoPrato.Text = "Sobremesa"
    End Sub

    Private Sub RegistarPrato_Click(sender As Object, e As EventArgs) Handles RegistarPrato.Click
        registar()
        mostra()
    End Sub

    Private Sub CriarPratoDia_Click(sender As Object, e As EventArgs) Handles CriarPratoDia.Click
        Dim pratodia As New PratoDia
        Cadeia(visivel2).Pratodias.Add(pratodia)
        visivell = Cadeia(visivel2).Pratodias.Count - 1
        mostra2
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        visivel2 = visivel2 - 1
        mostra()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        visivel2 = visivel2 + 1
        mostra()
    End Sub

    Private Sub AlterarPreco_Click(sender As Object, e As EventArgs) Handles AlterarPreco.Click
        Cadeia(visivel2).Pratos(visivel).Preco = Val(NovoPrecoTB.Text)
        mostra()
    End Sub

    Public Sub mostra2()
        If Cadeia(visivel2).Pratodias.Count > 0 Then
            If visivell < 0 Then
                visivell = 0
            ElseIf visivell > Cadeia(visivel2).Pratodias.Count - 1 Then
                visivell = Cadeia(visivel2).Pratodias.Count - 1
            End If

            If visivell = 0 Then
                Button1.Enabled = False
                Button2.Enabled = False
                Button3.Enabled = True
                Button4.Enabled = True
            ElseIf visivell = Cadeia(visivel2).Pratos.Count - 1 Then
                Button1.Enabled = True
                Button2.Enabled = True
                Button3.Enabled = False
                Button4.Enabled = False
            Else
                Button1.Enabled = True
                Button2.Enabled = True
                Button3.Enabled = True
                Button4.Enabled = True
            End If

            If visivell = 0 And Cadeia(visivel2).Pratodias.Count = 1 Then
                Button1.Enabled = False
                Button2.Enabled = False
                Button3.Enabled = False
                Button4.Enabled = False
                RegPratoDia.Visible = True
                Entrada.Enabled = True
                PratoPrincipal.Enabled = True
                Sobremesa.Enabled = True
                NomePrato.Enabled = True
                Preco.Enabled = True
            End If

            NomePrato.Text = Cadeia(visivel2).Pratodias(visivell).Nome
            Preco.Text = Cadeia(visivel2).Pratodias(visivell).Preco
            TipoPrato.Text = Cadeia(visivel2).Pratodias(visivell).Tipo

            PratoDias.Text = visivell + 1 & " de " & Cadeia(visivel2).Pratodias.Count



            Lista.Items.Clear()
            For k = 0 To Cadeia(visivel2).Ingredientes.Count - 1
                Lista.Items.Add(Cadeia(visivel2).Ingredientes(k).Nome & vbTab & Cadeia(visivel2).Ingredientes(k).Quantidade)
            Next

            ListaPratosDia.Items.Clear()
            For k = 0 To Cadeia(visivel2).Pratodias.Count - 1
                ListaPratosDia.Items.Add(Cadeia(visivel2).Pratodias(k).Nome)
            Next
        Else
            inicial()
        End If
    End Sub

    Public Sub registar()

        Dim temp As Integer
        Dim quantidades As ArrayList
        quantidades = New ArrayList
        Dim ingredientesnec As Ingredientes
        ingredientesnec = New Ingredientes

        If TipoPrato.Text <> "" Then
            For k = 0 To Lista.Items.Count - 1
                If Lista.GetItemChecked(k) = True Then
                    temp = InputBox("Qual é a quantidade necessaria do ingrediente " & Cadeia(visivel2).Ingredientes(k).Nome)
                    quantidades.Add(temp)
                    ingredientesnec.Add(Cadeia(visivel2).Ingredientes(k))
                End If

            Next
        End If
        Cadeia(visivel2).Pratos(visivel).Nome = NomePrato.Text
        Cadeia(visivel2).Pratos(visivel).Tipo = TipoPrato.Text
        Cadeia(visivel2).Pratos(visivel).Ingredientes = ingredientesnec
        Cadeia(visivel2).Pratos(visivel).Quantidades = quantidades
        Cadeia(visivel2).Pratos(visivel).Preco = Val(Preco.Text)


    End Sub

    Private Sub RegPratoDia_Click(sender As Object, e As EventArgs) Handles RegPratoDia.Click

        registar2()

        Cadeia(visivel2).Pratodias(visivell).Data = DateTimePicker1.Value
        mostra2()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        visivell = visivell + 1
        mostra2()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        visivell = 0
        mostra2()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        visivell = visivell - 1
        mostra2()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        visivell = Cadeia(visivel2).Pratodias.Count - 1
        mostra2()
    End Sub

    Public Sub registar2()
        Dim temp As Integer
        Dim quantidades As ArrayList
        quantidades = New ArrayList
        Dim ingredientesnec As Ingredientes
        ingredientesnec = New Ingredientes

        If TipoPrato.Text <> "" Then
            For k = 0 To Lista.Items.Count - 1
                If Lista.GetItemChecked(k) = True Then
                    temp = InputBox("Qual é a quantidade necessaria do ingrediente " & Cadeia(visivel2).Ingredientes(k).Nome)
                    quantidades.Add(temp)
                    ingredientesnec.Add(Cadeia(visivel2).Ingredientes(k))
                End If

            Next
        End If
        Cadeia(visivel2).Pratodias(visivell).Nome = NomePrato.Text
        Cadeia(visivel2).Pratodias(visivell).Tipo = TipoPrato.Text
        Cadeia(visivel2).Pratodias(visivell).Ingredientes = ingredientesnec
        Cadeia(visivel2).Pratodias(visivell).Quantidades = quantidades
        Cadeia(visivel2).Pratodias(visivell).Preco = Val(Preco.Text)

    End Sub
End Class