﻿Public Class ClienteVips
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewClienteVip As ClienteVip)
        Me.List.Add(NewClienteVip)
    End Sub

    Public Sub Remove(ByVal oldClienteVip As ClienteVip)
        Me.List.Remove(oldClienteVip)
    End Sub

    Default Public Property item(ByVal index As Integer) As ClienteVip
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As ClienteVip)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewClienteVip As ClienteVip)
        Me.List.Insert(index, NewClienteVip)
    End Sub

End Class
