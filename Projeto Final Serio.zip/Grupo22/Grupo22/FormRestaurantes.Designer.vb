﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRestaurantes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NomeCliente = New System.Windows.Forms.TextBox()
        Me.NIF = New System.Windows.Forms.TextBox()
        Me.DataNascimento = New System.Windows.Forms.DateTimePicker()
        Me.Nome = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ProcurarCliente = New System.Windows.Forms.Button()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.FazerReserva = New System.Windows.Forms.Button()
        Me.Numero = New System.Windows.Forms.Label()
        Me.DataReserva = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CustoTotal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox3 = New System.Windows.Forms.CheckedListBox()
        Me.GridPratos = New System.Windows.Forms.DataGridView()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ReceitaTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CheckedListBox4 = New System.Windows.Forms.CheckedListBox()
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NomeCliente
        '
        Me.NomeCliente.Location = New System.Drawing.Point(144, 103)
        Me.NomeCliente.Name = "NomeCliente"
        Me.NomeCliente.Size = New System.Drawing.Size(200, 20)
        Me.NomeCliente.TabIndex = 0
        '
        'NIF
        '
        Me.NIF.Location = New System.Drawing.Point(144, 187)
        Me.NIF.Name = "NIF"
        Me.NIF.Size = New System.Drawing.Size(200, 20)
        Me.NIF.TabIndex = 2
        '
        'DataNascimento
        '
        Me.DataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataNascimento.Location = New System.Drawing.Point(144, 147)
        Me.DataNascimento.Name = "DataNascimento"
        Me.DataNascimento.Size = New System.Drawing.Size(200, 20)
        Me.DataNascimento.TabIndex = 3
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(103, 106)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(35, 13)
        Me.Nome.TabIndex = 4
        Me.Nome.Text = "Nome"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 147)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Data Nascimento"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(114, 190)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "NIF"
        '
        'ProcurarCliente
        '
        Me.ProcurarCliente.Location = New System.Drawing.Point(383, 91)
        Me.ProcurarCliente.Name = "ProcurarCliente"
        Me.ProcurarCliente.Size = New System.Drawing.Size(87, 42)
        Me.ProcurarCliente.TabIndex = 9
        Me.ProcurarCliente.Text = "Procurar Cliente"
        Me.ProcurarCliente.UseVisualStyleBackColor = True
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(288, 40)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(45, 23)
        Me.Botao4.TabIndex = 15
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(237, 40)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(45, 23)
        Me.Botao3.TabIndex = 16
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(65, 40)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(45, 23)
        Me.Botao1.TabIndex = 17
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(116, 40)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(45, 23)
        Me.Botao2.TabIndex = 18
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(179, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "0 de 0"
        '
        'FazerReserva
        '
        Me.FazerReserva.Location = New System.Drawing.Point(383, 217)
        Me.FazerReserva.Name = "FazerReserva"
        Me.FazerReserva.Size = New System.Drawing.Size(87, 42)
        Me.FazerReserva.TabIndex = 28
        Me.FazerReserva.Text = "Fazer Reserva"
        Me.FazerReserva.UseVisualStyleBackColor = True
        '
        'Numero
        '
        Me.Numero.AutoSize = True
        Me.Numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Numero.Location = New System.Drawing.Point(672, 27)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(150, 16)
        Me.Numero.TabIndex = 29
        Me.Numero.Text = "Restaurante Numero"
        '
        'DataReserva
        '
        Me.DataReserva.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataReserva.Location = New System.Drawing.Point(144, 226)
        Me.DataReserva.Name = "DataReserva"
        Me.DataReserva.Size = New System.Drawing.Size(200, 20)
        Me.DataReserva.TabIndex = 30
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(62, 232)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Data Reserva"
        '
        'CustoTotal
        '
        Me.CustoTotal.Location = New System.Drawing.Point(191, 592)
        Me.CustoTotal.Name = "CustoTotal"
        Me.CustoTotal.Size = New System.Drawing.Size(238, 20)
        Me.CustoTotal.TabIndex = 34
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(108, 595)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = " Total Reserva"
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(117, 282)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(180, 259)
        Me.CheckedListBox1.TabIndex = 38
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Location = New System.Drawing.Point(341, 282)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(180, 259)
        Me.CheckedListBox2.TabIndex = 39
        '
        'CheckedListBox3
        '
        Me.CheckedListBox3.FormattingEnabled = True
        Me.CheckedListBox3.Location = New System.Drawing.Point(564, 282)
        Me.CheckedListBox3.Name = "CheckedListBox3"
        Me.CheckedListBox3.Size = New System.Drawing.Size(180, 259)
        Me.CheckedListBox3.TabIndex = 40
        '
        'GridPratos
        '
        Me.GridPratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridPratos.Location = New System.Drawing.Point(551, 76)
        Me.GridPratos.Name = "GridPratos"
        Me.GridPratos.Size = New System.Drawing.Size(441, 183)
        Me.GridPratos.TabIndex = 41
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(191, 566)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(524, 20)
        Me.TextBox1.TabIndex = 42
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(120, 569)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Ingredientes"
        '
        'ReceitaTotal
        '
        Me.ReceitaTotal.Location = New System.Drawing.Point(518, 592)
        Me.ReceitaTotal.Name = "ReceitaTotal"
        Me.ReceitaTotal.Size = New System.Drawing.Size(197, 20)
        Me.ReceitaTotal.TabIndex = 44
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(435, 595)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Receita Total"
        '
        'CheckedListBox4
        '
        Me.CheckedListBox4.FormattingEnabled = True
        Me.CheckedListBox4.Location = New System.Drawing.Point(787, 282)
        Me.CheckedListBox4.Name = "CheckedListBox4"
        Me.CheckedListBox4.Size = New System.Drawing.Size(180, 259)
        Me.CheckedListBox4.TabIndex = 46
        '
        'FormRestaurantes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1035, 628)
        Me.Controls.Add(Me.CheckedListBox4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ReceitaTotal)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GridPratos)
        Me.Controls.Add(Me.CheckedListBox3)
        Me.Controls.Add(Me.CheckedListBox2)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CustoTotal)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.DataReserva)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.FazerReserva)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.Botao4)
        Me.Controls.Add(Me.ProcurarCliente)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Nome)
        Me.Controls.Add(Me.DataNascimento)
        Me.Controls.Add(Me.NIF)
        Me.Controls.Add(Me.NomeCliente)
        Me.Name = "FormRestaurantes"
        Me.Text = "FormRestaurantes"
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NomeCliente As TextBox
    Friend WithEvents NIF As TextBox
    Friend WithEvents DataNascimento As DateTimePicker
    Friend WithEvents Nome As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ProcurarCliente As Button
    Friend WithEvents Botao4 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao1 As Button
    Friend WithEvents Botao2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents FazerReserva As Button
    Friend WithEvents Numero As Label
    Friend WithEvents DataReserva As DateTimePicker
    Friend WithEvents Label7 As Label
    Friend WithEvents CustoTotal As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox3 As CheckedListBox
    Friend WithEvents GridPratos As DataGridView
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ReceitaTotal As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents CheckedListBox4 As CheckedListBox
End Class
